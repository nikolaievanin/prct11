﻿// practic112.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//variat5

#include <iostream>
using namespace std;
template <typename T>
T findMin(const T* array, int size) {
    if (size <= 0) {
        cerr << "Error: Array size must be greater than 0." << endl;
        return T{};
    }

    T min = array[0];
    for (int i = 1; i < size; ++i) {
        if (array[i] < min) {
            min = array[i];
        }
    }

    return min;
}

int main() {
    int intArray[] = { 5, 2, 8, 1, 9 };
    double doubleArray[] = { 3.14, 2.71, 1.618, 0.577 };

    int minInt = findMin(intArray, 5);
    double minDouble = findMin(doubleArray, 4);

    cout << "Minimum element in intArray: " << minInt << endl;
    cout << "Minimum element in doubleArray: " << minDouble << endl;

    return 0;
}
