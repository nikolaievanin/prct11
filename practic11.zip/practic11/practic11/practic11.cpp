﻿// practic11.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//variant5

#include <iostream>
using namespace std;
template<typename T>
T factorial(T n) {
    if (n == 0 || n == 1) {
        return 1;
    }
    else {
        return n * factorial(n - 1);
    }
}

int main() {
    int num;
    cout << "Input the data1:" << endl;
    cin >> num;

    double doubleNum;
    cout << "Input the data2:" << endl;
    cin >> doubleNum;
    cout << "Factorial of " << doubleNum << " is: " << factorial(doubleNum) << endl;
    cout << "Factorial of " << num << " is: " << factorial(num) << endl;

    return 0;
}

